// __tests__/example.test.ts
export {};

test('simple test', () => {
  expect(true).toBe(true);
});
