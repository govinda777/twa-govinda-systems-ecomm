import globals from 'globals';
import { FlatCompat } from '@eslint/eslintrc';
const compat = new FlatCompat();

export default [
  {
    ignores: ['node_modules/**'],
  },
  {
    languageOptions: {
      ecmaVersion: 2021,
      sourceType: 'module',
      globals: {
        ...globals.browser,
        ...globals.es2021,
      },
    },
    rules: {
      // React-specific rules
      'react/react-in-jsx-scope': 'off', // Desativa a necessidade de importar React em arquivos JSX (React 17+)
      
      // TypeScript-specific rules
      '@typescript-eslint/no-unused-vars': ['warn', { varsIgnorePattern: '^_' }], // Permite variáveis prefixadas com "_" ficarem sem uso
      '@typescript-eslint/no-explicit-any': 'off', // Permite o uso de "any"
      '@typescript-eslint/no-require-imports': 'off', // Desativa a regra que proíbe require em TypeScript
      
      // Adicional: Suprime expressões que não afetam o código (para reduzir os erros do tipo "Expected an assignment or function call")
      '@typescript-eslint/no-unused-expressions': ['warn', { allowShortCircuit: true, allowTernary: true }],

      // Adicional: Permite a aliasing do `this` (caso o erro `@typescript-eslint/no-this-alias` esteja ocorrendo)
      '@typescript-eslint/no-this-alias': 'off',
    },
  },
  ...compat.extends('plugin:@typescript-eslint/recommended'), // Extensões recomendadas do TypeScript
  ...compat.extends('plugin:react/recommended'), // Extensões recomendadas do React
];
